import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.css";
import ProductsService from "../../services/ProductsService";

const ListProducts = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    listAllProducts();
  }, []);

  const listAllProducts = () => {
    ProductsService.listProducts()
      .then((response) => {
        setProducts(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="container">
      <div className="row">
        <div className="text-center mt-3">
          <h1>List Products Page</h1>
        </div>
      </div>
      <div>
        <table className="table table-dark">
          <thead>
            <tr>
              <th scope="col">Prod-Id</th>
              <th scope="col">Name</th>
              <th scope="col">Price</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product, counter) => (
              <tr key={product.id}>
                <td>{counter + 1}</td>
                <td>{product.name}</td>
                <td>{product.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ListProducts;
