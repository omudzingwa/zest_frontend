import React from "react";

const DeleteProduct = () => {
  return <div>DeleteProduct</div>;
};

export default DeleteProduct;
