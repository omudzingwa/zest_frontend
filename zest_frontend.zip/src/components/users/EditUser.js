import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.css";
import { useNavigate, useParams } from "react-router-dom";
import UsersService from "../../services/UsersService";

const EditUser = () => {
  const { id } = useParams();

  const [user, setUser] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {
    UsersService.findUserById_jsonserver(id)
      .then((res) => {
        //console.log(res.data);
        setUser(res.data);
      })
      .catch((error) => {
        console.log(error);
      });

    /*UsersService.findUserById_mysql(id)
      .then((res) => {
        //console.log(res.data);
        console.log(res.data);
        setUser(res.data);
      })
      .catch((error) => {
        console.log(error);
      });*/
  }, []);

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const userUpdate = (e) => {
    e.preventDefault();
    UsersService.updateUser(user)
      .then((res) => {
        navigate("/");
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <div className="container mt-3">
        <div className="row">
          <div className="col-md-6 offset-md-3">
            <div className="card">
              <div className="card-header fs-3 text-center">Edit User</div>
              <div className="card-body">
                <form onSubmit={(e) => userUpdate(e)}>
                  <div className="mb-3">
                    <label className="form-label">ID</label>
                    <input
                      className="form-control"
                      type="text"
                      name="id"
                      id="id"
                      value={id}
                      disabled
                    />
                  </div>
                  <div className="mb-3">
                    <label>Username</label>
                    <input
                      type="text"
                      id="username"
                      name="username"
                      className="form-control"
                      value={user.username}
                      onChange={(e) => handleChange(e)}
                    />
                  </div>

                  <div className="mb-3">
                    <label>Password</label>
                    <input
                      type="text"
                      id="password"
                      name="password"
                      className="form-control"
                      value={user.password}
                      onChange={(e) => handleChange(e)}
                    />
                  </div>
                  <button className="btn btn-primary col-md-12">Update</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditUser;
